beforeAll {


}

beforeEach {
    set "light.norden_tuer" feature "brightness" to "0"
    set "light.norden_fenster" feature "brightness" to "0"
    set "light.sueden_tuer" feature "brightness" to "0"
    set "light.sueden_fenster" feature "brightness" to "0"
}

test "TC_S3_Conservation_100" {
    relation: conservation tolerance: 0.05
    actuators [ "light.norden_tuer" feature "brightness", "light.sueden_tuer" feature "brightness" ]
    sensors [ "Illuminance.Room518a_Ceiling" feature "Illuminance" ]
    sourceAction [ "1", "0" ]
    followUpAction [ "0", "1" ]
}

test "TC_S3_Conservation_90" {
    relation: conservation tolerance: 0.05
    actuators [ "light.norden_tuer" feature "brightness", "light.sueden_tuer" feature "brightness" ]
    sensors [ "Illuminance.Room518a_Ceiling" feature "Illuminance" ]
    sourceAction [ "0.9", "0.1" ]
    followUpAction [ "0.1", "0.9" ]
}

test "TC_S3_Conservation_75" {
    relation: conservation tolerance: 0.05
    actuators [ "light.norden_tuer" feature "brightness", "light.sueden_tuer" feature "brightness" ]
    sensors [ "Illuminance.Room518a_Ceiling" feature "Illuminance" ]
    sourceAction [ "0.75", "0.25" ]
    followUpAction [ "0.25", "0.75" ]
}

test "TC_S3_Conservation_65" {
    relation: conservation tolerance: 0.05
    actuators [ "light.norden_tuer" feature "brightness", "light.sueden_tuer" feature "brightness" ]
    sensors [ "Illuminance.Room518a_Ceiling" feature "Illuminance" ]
    sourceAction [ "0.65", "0.35" ]
    followUpAction [ "0.35", "0.65" ]
}



afterAll {
    set "light.norden_tuer" feature "brightness" to "0"
    set "light.norden_fenster" feature "brightness" to "0"
    set "light.sueden_tuer" feature "brightness" to "0"
    set "light.sueden_fenster" feature "brightness" to "0"
}
